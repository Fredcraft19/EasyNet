using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyNet.Manager;
using EasyNet_BackEnd.System;
using EasyNet_BackEnd.Data;
using TMPro;

public class BTN_Spawn : MonoBehaviour
{
    private NetworkManager Network;
    public TextMeshProUGUI buttonText;
    public TMP_InputField input;

    void Awake()
    {
        buttonText.text = "Connect";
        Network = FindObjectOfType<NetworkManager>();
    }
    public void ClickedBTN()
    {
        if (!Network.IsConnected)
        {
            Network.Connect();
        }
        else if (!Network.InRoom)
        {
            Network.JoinRoom(input.text ?? "Base64");
        }
        else
        {
            Network.SpawnPlayer();
            Destroy(gameObject);
        }
    }
    void Update()
    {
        if (!Network.IsConnected)
            buttonText.text = "Connect";
        else if (!Network.InRoom)
            buttonText.text = $"Join Room: {input.text}";
        else
            buttonText.text = "Spawn";
        
    }
}
