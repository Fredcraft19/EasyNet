using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyNet.View;
using NetworkView = EasyNet.View.NetworkView;
public class SimpleMovement : MonoBehaviour
{
    private int xDelta;
    private int yDelta;
    public float speed;
    void Update()
    {
        if (!GetComponent<NetworkView>().IsPlayers) { return; }
        xDelta = 0;
        yDelta = 0;
        if (Input.GetKey(KeyCode.W))
        {
            yDelta = 1;
        }
        else if(Input.GetKey(KeyCode.S))
        {            
            yDelta = -1;
        }

        if (Input.GetKey(KeyCode.A))
        {
            xDelta = -1;
        }
        else if(Input.GetKey(KeyCode.D))
        {
            xDelta = 1;
        }

        transform.position += new Vector3(xDelta, 0f, yDelta) * speed * Time.deltaTime;
    }
}
