using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyNet;
using TMPro;
using EasyNet.View;
using NetworkView = EasyNet.View.NetworkView;
class IncreaseValueBTN : MonoBehaviour
{
    public NetworkView network;
    public RPCTarget target;
    public TextMeshProUGUI display;
    public int value;
    void Start()
    {
        network.BindRPC<int>("Add", IncreaseValue);
    }
    public void Clicked()
    {
        network.RPC("Add", target, 1);
    }
    public void IncreaseValue(int x)
    {
        value += x;
    }
    void Update()
    {
        display.text = value.ToString();
    }
}
